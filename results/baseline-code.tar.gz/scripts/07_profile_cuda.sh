#!/usr/bin/env bash
set -euo pipefail
source "$(cd "$(dirname "$0")" && pwd)/common.sh"

[[ "$ACCELERATOR_BACKEND_RESOLVED" == cuda ]] || die "This profiler wrapper requires CUDA."
require_file "$LLAMA_SERVER_BIN"
require_file "$MODEL_PATH"
PROFILE_TOOL="${PROFILE_TOOL:-nsys}"
PROFILE_CONCURRENCY="${PROFILE_CONCURRENCY:-8}"
PROFILE_PORT="${PROFILE_PORT:-8081}"
PROFILE_OUTPUT="${PROFILE_OUTPUT:-$PROJECT_ROOT/results/profile-$MODEL_ALIAS-c$PROFILE_CONCURRENCY-$PROFILE_TOOL-$(date -u +%Y%m%dT%H%M%SZ)}"
CUDA_TOOLKIT_ROOT="${CUDA_TOOLKIT_ROOT:-$(cd "$(dirname "$(command -v nvcc)")/.." && pwd)}"
CUDA_TOOLKIT_LIB="$CUDA_TOOLKIT_ROOT/targets/x86_64-linux/lib"
mkdir -p "$PROJECT_ROOT/.run"
g++ -std=c++17 -shared -fPIC -pthread \
  -I "$CUDA_TOOLKIT_ROOT/targets/x86_64-linux/include" \
  "$PROJECT_ROOT/benchmark/profile_gate.cpp" \
  -L "$CUDA_TOOLKIT_LIB" -Wl,-rpath,"$CUDA_TOOLKIT_LIB" -lcudart \
  -o "$PROJECT_ROOT/.run/profile_gate.so"
if [[ "$PROFILE_TOOL" == nsys ]]; then
  PROFILE_BIN="${NSYS_BIN:-$(command -v nsys || true)}"
else
  PROFILE_BIN="${NCU_BIN:-$(command -v ncu || true)}"
fi
[[ -n "$PROFILE_BIN" ]] || die "Set NSYS_BIN or NCU_BIN to the profiler executable."
CUDA_VISIBLE_DEVICES="$GPU_DEVICE" python3 "$PROJECT_ROOT/benchmark/profile_cuda.py" \
  --tool "$PROFILE_TOOL" --profiler "$PROFILE_BIN" \
  --gate-library "$PROJECT_ROOT/.run/profile_gate.so" \
  --base-url "http://$SERVER_HOST:$PROFILE_PORT" --model "$MODEL_ALIAS" \
  --concurrency "$PROFILE_CONCURRENCY" \
  --prompt-tokens "$TARGET_PROMPT_TOKENS" --output-tokens "$MAX_OUTPUT_TOKENS" \
  --topics "$PROJECT_ROOT/prompts/topics.txt" --seed "$RANDOM_SEED" \
  --timeout "$REQUEST_TIMEOUT_SECONDS" --output "$PROFILE_OUTPUT" \
  --kernel-regex "${PROFILE_KERNEL_REGEX:-mul_mat_q|mul_mat_vec_q}" \
  --launch-count "${PROFILE_LAUNCH_COUNT:-4}" --launch-skip "${PROFILE_LAUNCH_SKIP:-0}" \
  -- "$LLAMA_SERVER_BIN" --model "$MODEL_PATH" --alias "$MODEL_ALIAS" \
  --host "$SERVER_HOST" --port "$PROFILE_PORT" --n-gpu-layers "$GPU_LAYERS" \
  --parallel "$SERVER_PARALLEL" --ctx-size "$SERVER_CTX_SIZE" \
  --batch-size "$SERVER_BATCH_SIZE" --ubatch-size "$SERVER_UBATCH_SIZE" \
  --flash-attn "$FLASH_ATTN" --cont-batching --no-cache-prompt \
  --cache-ram 0 --no-cache-idle-slots --metrics --jinja
