#!/usr/bin/env python3
"""Run/resume a fixed three-format CUDA HTTP study; --dry-run touches no GPU."""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "config/cuda-study.env"
PIN = "3f5e94d7c2ab2267fe39852051777fe30c1f49ef"
KEYS = "EXPERIMENT_NAME ACCELERATOR_BACKEND LLAMA_CPP_REF GPU_DEVICE SERVER_HOST SERVER_PORT SERVER_PARALLEL SERVER_CTX_SIZE SERVER_BATCH_SIZE SERVER_UBATCH_SIZE GPU_LAYERS FLASH_ATTN CONCURRENCY_LEVELS REQUESTS_PER_LEVEL REPETITIONS TARGET_PROMPT_TOKENS MAX_OUTPUT_TOKENS WARMUP_REQUESTS REQUEST_TIMEOUT_SECONDS RANDOM_SEED".split()


def stamp():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def valid(path, requests, concurrency):
    try:
        data = json.loads(path.read_text())
        s = data["summary"]
        return (data["configuration"]["requests"] == requests
                and data["configuration"]["concurrency"] == concurrency
                and data["configuration"]["max_output_tokens"] == 128
                and data["configuration"]["target_prompt_tokens"] == 2048
                and s["successful_requests"] == requests and s["failed_requests"] == 0
                and s["output_length_invalid_requests"] == 0
                and s["cache_counter_available_requests"] == requests
                and s["cached_prompt_tokens"] == 0 and s["max_client_inflight"] == concurrency
                and len(data["requests"]) == requests and all(r["ok"] for r in data["requests"]))
    except (OSError, ValueError, KeyError, TypeError):
        return False


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--repetitions", type=int, default=3)
    parser.add_argument("--requests", type=int, default=16)
    parser.add_argument("--manifest", type=Path, default=ROOT / "models/manifest.json")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "results/cuda-study")
    args = parser.parse_args()
    if args.repetitions < 1 or args.requests < 8:
        parser.error("Use at least one repetition and eight requests (for concurrency 8).")
    exported = subprocess.check_output(["bash", "-c", 'set -a; source "$1"; env -0', "bash", str(CONFIG)])
    resolved = dict(item.decode().split("=", 1) for item in exported.split(b"\0") if item)
    cfg = {key: resolved[key] for key in KEYS}
    cfg.update(REPETITIONS=str(args.repetitions), REQUESTS_PER_LEVEL=str(args.requests))
    manifest = json.loads(args.manifest.read_text())
    if [m["quant"] for m in manifest] != ["Q8_0", "Q4_K_M", "IQ1_M"]:
        raise RuntimeError("Model manifest must contain Q8_0, Q4_K_M, IQ1_M in that order.")
    family = manifest[0].get("model_family", re.sub(r"([.-]Q8_0)?\.gguf$", "", manifest[0]["filename"]))
    binary = ROOT / "vendor/llama.cpp/build-cuda/bin/llama-server"
    plan = [(rep, manifest[(rep - 1 + index) % 3]) for rep in range(1, args.repetitions + 1) for index in range(3)]
    if args.dry_run:
        print(json.dumps({"configuration": cfg, "model_family": family, "manifest": str(args.manifest), "binary": str(binary), "output": str(args.output_dir),
                          "loads": [{"repetition": r, "quant": m["quant"], "model": m["filename"],
                                     "discarded_warmup": "8 requests at concurrency 8, 2048/128 tokens",
                                     "concurrency_order": [8, 1] if r % 2 == 0 else [1, 8]} for r, m in plan]}, indent=2))
        return 0

    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    env = os.environ | cfg | {"CONFIG_FILE": str(CONFIG), "LLAMA_SERVER_BIN": str(binary),
                             "LLAMA_CPP_DIR": str(ROOT / "vendor/llama.cpp"), "CUDA_VISIBLE_DEVICES": "0"}
    def command(argv, logfile, extra=None, check=True):
        with (output / "commands.jsonl").open("a") as log:
            log.write(json.dumps({"utc": stamp(), "argv": list(map(str, argv)), "environment": cfg | (extra or {})}) + "\n")
        with logfile.open("w") as log:
            return subprocess.run(argv, cwd=ROOT, env=env | (extra or {}), stdout=log, stderr=subprocess.STDOUT, check=check)

    commit = subprocess.check_output(["git", "-C", str(ROOT / "vendor/llama.cpp"), "rev-parse", "HEAD"], text=True).strip()
    if commit != PIN:
        raise RuntimeError(f"Expected llama.cpp {PIN}; checkout is {commit}.")
    identity = {"configuration": cfg, "model_family": family, "manifest": manifest, "manifest_path": str(args.manifest.resolve()), "llama_cpp_commit": commit,
                "binary_sha256": digest(binary), "kv_types": {"K": "f16", "V": "f16"},
                "code_sha256": {str(p.relative_to(ROOT)): digest(p) for p in
                                [CONFIG, ROOT / "config/experiment.env", Path(__file__), ROOT / "benchmark/load_test.py",
                                 ROOT / "scripts/common.sh", ROOT / "scripts/03_start_server.sh", ROOT / "scripts/06_stop_server.sh", ROOT / "prompts/topics.txt"]},
                "models": [m | {"bytes": (ROOT / "models" / m["filename"]).stat().st_size,
                                "sha256": digest(ROOT / "models" / m["filename"])} for m in manifest]}
    fingerprint = hashlib.sha256(json.dumps(identity, sort_keys=True).encode()).hexdigest()
    progress_path = output / "progress.json"
    progress = json.loads(progress_path.read_text()) if progress_path.exists() else {"fingerprint": fingerprint, "cells": {}}
    if progress["fingerprint"] != fingerprint:
        raise RuntimeError("Resume fingerprint differs: use a new output directory for changed code, models or configuration.")
    write_json(output / "manifest.json", identity)
    shutil.copy2(CONFIG, output / "cuda-study.env")
    command([str(binary), "--version"], output / "binary-version.txt")
    command(["nvidia-smi", "-q", "-i", "0"], output / "gpu-metadata.txt")
    command(["nvidia-smi", "--query-compute-apps=pid,process_name,used_memory", "--format=csv"], output / "gpu-processes-before.csv")
    write_json(progress_path, progress)
    base_url = f"http://{cfg['SERVER_HOST']}:{cfg['SERVER_PORT']}"
    shared_log = ROOT / "logs/llama-server-cuda.log"

    def snapshot(path):
        try:
            with urllib.request.urlopen(base_url + "/metrics", timeout=10) as response:
                path.write_bytes(response.read())
        except Exception as exc:
            path.write_text(f"# metrics unavailable: {exc}\n")

    def load_command(model, rep, concurrency, count, path):
        return [sys.executable, str(ROOT / "benchmark/load_test.py"), "--base-url", base_url,
                "--model", model, "--topics", str(ROOT / "prompts/topics.txt"), "--concurrency", str(concurrency),
                "--requests", str(count), "--target-prompt-tokens", "2048", "--max-output-tokens", "128",
                "--warmup-requests", "0", "--timeout", cfg["REQUEST_TIMEOUT_SECONDS"],
                "--seed", str(int(cfg["RANDOM_SEED"]) + rep), "--repetition", str(rep), "--output", str(path)]

    for rep, model in plan:
        quant = model["quant"]
        alias = f"{family}-{quant}"
        folder = output / quant / f"r{rep}"
        cells = [(c, f"{quant}/r{rep}/c{c}") for c in ([8, 1] if rep % 2 == 0 else [1, 8])]
        pending = [(c, key) for c, key in cells if not (progress["cells"].get(key, {}).get("status") == "complete"
                   and valid(output / progress["cells"][key]["raw"], args.requests, c))]
        if not pending:
            print(f"Skipping valid completed {quant} repetition {rep}", flush=True)
            continue
        folder.mkdir(parents=True, exist_ok=True)
        extra = {"MODEL_FILENAME": model["filename"], "MODEL_PATH": str(ROOT / "models" / model["filename"]),
                 "MODEL_ALIAS": alias, "MODEL_URL": model["url"]}
        pidfile = ROOT / ".run/llama-server-cuda.pid"
        if pidfile.exists() and Path(f"/proc/{pidfile.read_text().strip()}").exists():
            raise RuntimeError("A managed server is already running; stop it before starting this study.")
        try:
            command(["bash", "scripts/03_start_server.sh"], folder / "start.log", extra)
            command(load_command(alias, rep, 8, 8, folder / "warmup-discarded.json"), folder / "warmup-discarded.log")
            if not valid(folder / "warmup-discarded.json", 8, 8):
                raise RuntimeError("Full concurrency warmup failed validation.")
            for concurrency, key in pending:
                cell = folder / f"c{concurrency}"
                if cell.exists():
                    cell.rename(folder / f"c{concurrency}-previous-{time.time_ns()}")
                cell.mkdir()
                progress["cells"][key] = {"status": "running", "started_utc": stamp(), "raw": str((cell / "raw.json").relative_to(output))}
                write_json(progress_path, progress)
                snapshot(cell / "metrics-before.prom")
                offset = shared_log.stat().st_size
                query = "timestamp,index,uuid,utilization.gpu,utilization.memory,memory.used,power.draw,temperature.gpu,clocks.sm,clocks.mem"
                telemetry_command = ["nvidia-smi", "-i", "0", f"--query-gpu={query}", "--format=csv", "-lms", "200"]
                with (cell / "telemetry.csv").open("w") as samples:
                    telemetry = subprocess.Popen(telemetry_command, stdout=samples, stderr=subprocess.STDOUT)
                    started = time.time()
                    try:
                        result = command(load_command(alias, rep, concurrency, args.requests, cell / "raw.json"), cell / "client.log", check=False)
                    finally:
                        telemetry.terminate()
                        telemetry.wait(timeout=10)
                        write_json(cell / "telemetry-window.json", {"invocation_started_unix": started, "invocation_finished_unix": time.time(),
                                   "command": telemetry_command, "interpretation": "utilization.gpu and utilization.memory are sampled duty percentages, not achieved bandwidth or occupancy; crop to raw.json summary started_unix_seconds/finished_unix_seconds for the retained request window"})
                        snapshot(cell / "metrics-after.prom")
                        with shared_log.open("rb") as stream:
                            stream.seek(offset)
                            (cell / "server.log").write_bytes(stream.read())
                        shutil.copy2(shared_log, folder / "server.log")
                accepted = result.returncode == 0 and valid(cell / "raw.json", args.requests, concurrency)
                progress["cells"][key].update(status="complete" if accepted else "failed", finished_utc=stamp())
                write_json(progress_path, progress)
                if not accepted:
                    raise RuntimeError(f"Invalid cell {key}; inspect {cell} before resuming.")
                print(f"Completed {key}", flush=True)
        finally:
            command(["bash", "scripts/06_stop_server.sh"], folder / "stop.log", extra, check=False)
            if shared_log.exists():
                shutil.copy2(shared_log, folder / "server.log")
    print(f"Study complete: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
