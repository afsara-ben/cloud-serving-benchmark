#!/usr/bin/env python3
"""Capture one warmed concurrent HTTP burst with Nsight Systems or Compute.

The remaining command-line arguments after -- are the exact llama-server
command. Profiler timings are diagnostic and never performance benchmark rows.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import collections
import csv
import json
import os
import pathlib
import signal
import sqlite3
import statistics
import subprocess
import threading
import time
import urllib.request

from load_test import ServerTokenizer, finalize_record, make_messages, stream_completion


DEFAULT_METRICS = ",".join([
    "gpu__time_duration.sum",
    "dram__bytes_read.sum", "dram__bytes_write.sum",
    "dram__throughput.avg.pct_of_peak_sustained_elapsed",
    "lts__t_sector_hit_rate.pct",
    "sm__throughput.avg.pct_of_peak_sustained_elapsed",
    "sm__warps_active.avg.pct_of_peak_sustained_active",
    "sm__pipe_tensor_cycles_active.avg.pct_of_peak_sustained_active",
])


def kernel_class(name: str) -> str:
    if "mul_mat_vec_q" in name:
        return "quantized_matvec"
    if "mul_mat_q" in name:
        return "quantized_matmul"
    if "dequantize" in name:
        return "dequantization"
    if "quantize" in name:
        return "activation_quantization"
    # Attention kernels may contain "mma"; classify them before generic matrix kernels.
    if any(token in name.lower() for token in ["fattn", "attention", "flash_attn", "flashattn"]):
        return "attention"
    if any(token in name.lower() for token in ["gemm", "gemv", "mul_mat", "mma"]):
        return "other_matrix_multiply"
    if "norm" in name:
        return "normalization"
    if "rope" in name:
        return "rotary_position"
    return "other"


def union_duration(intervals: list[tuple[int, int]]) -> int:
    total = 0
    last_end = -1
    for start, end in sorted(intervals):
        total += max(0, end - max(start, last_end))
        last_end = max(last_end, end)
    return total


def write_csv(path: pathlib.Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text("")
        return
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def summarize_sqlite(sqlite_path: pathlib.Path, output: pathlib.Path) -> None:
    """Summarize CUDA activity without inferring unavailable hardware counters."""
    output.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(f"file:{sqlite_path.resolve()}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if "CUPTI_ACTIVITY_KIND_KERNEL" not in tables:
        raise SystemExit("No CUDA kernel activity table found; capture is invalid for kernel analysis")
    kernels = [dict(row) for row in connection.execute("""
        SELECT k.start, k.end, s.value AS kernel, k.deviceId, k.streamId,
               k.gridX, k.gridY, k.gridZ, k.blockX, k.blockY, k.blockZ,
               k.registersPerThread, k.staticSharedMemory, k.dynamicSharedMemory,
               k.localMemoryPerThread, k.graphNodeId
        FROM CUPTI_ACTIVITY_KIND_KERNEL AS k JOIN StringIds AS s ON s.id=k.demangledName
        ORDER BY k.start
    """)]
    if not kernels:
        raise SystemExit("The trace contains no CUDA kernels")
    grouped = collections.defaultdict(list)
    classes = collections.defaultdict(list)
    for kernel in kernels:
        kernel["duration_ns"] = kernel["end"] - kernel["start"]
        kernel["class"] = kernel_class(kernel["kernel"])
        # Keep different batch shapes/resources separate rather than averaging them away.
        key = tuple(kernel[field] for field in ["kernel", "deviceId", "gridX", "gridY", "gridZ",
                    "blockX", "blockY", "blockZ", "registersPerThread", "staticSharedMemory", "dynamicSharedMemory"])
        grouped[key].append(kernel)
        classes[kernel["class"]].append(kernel["duration_ns"])
    total = sum(kernel["duration_ns"] for kernel in kernels)
    grouped_rows = []
    for values in grouped.values():
        first = values[0]
        durations = [value["duration_ns"] for value in values]
        grouped_rows.append({
            "kernel": first["kernel"], "class": first["class"], "calls": len(values),
            "total_ms": sum(durations) / 1e6, "kernel_time_share_pct": 100 * sum(durations) / total,
            "mean_us": statistics.mean(durations) / 1000, "median_us": statistics.median(durations) / 1000,
            "min_us": min(durations) / 1000, "max_us": max(durations) / 1000,
            "grid": "x".join(str(first[f"grid{dim}"]) for dim in "XYZ"),
            "block": "x".join(str(first[f"block{dim}"]) for dim in "XYZ"),
            "registers_per_thread": first["registersPerThread"],
            "shared_bytes_per_block": first["staticSharedMemory"] + first["dynamicSharedMemory"],
            "local_bytes_per_thread": first["localMemoryPerThread"], "device": first["deviceId"],
        })
    grouped_rows.sort(key=lambda row: row["total_ms"], reverse=True)
    write_csv(output / "kernels.csv", kernels)
    write_csv(output / "kernel_summary.csv", grouped_rows)
    class_rows = [{"class": name, "calls": len(durations), "total_ms": sum(durations) / 1e6,
                   "kernel_time_share_pct": 100 * sum(durations) / total}
                  for name, durations in sorted(classes.items(), key=lambda item: -sum(item[1]))]
    write_csv(output / "kernel_classes.csv", class_rows)

    copies = []
    if "CUPTI_ACTIVITY_KIND_MEMCPY" in tables:
        copies = [dict(row) for row in connection.execute("""
            SELECT e.label AS direction, count(*) AS calls, sum(m.bytes) AS bytes,
                   sum(m.end-m.start)/1000000.0 AS total_ms
            FROM CUPTI_ACTIVITY_KIND_MEMCPY AS m
            LEFT JOIN ENUM_CUDA_MEMCPY_OPER AS e ON m.copyKind=e.id
            GROUP BY m.copyKind ORDER BY total_ms DESC
        """)]
    write_csv(output / "memory_copies.csv", copies)
    api_rows = []
    if "CUPTI_ACTIVITY_KIND_RUNTIME" in tables:
        api_rows = [dict(row) for row in connection.execute("""
            SELECT s.value AS api, count(*) AS calls, sum(r.end-r.start)/1000000.0 AS total_ms
            FROM CUPTI_ACTIVITY_KIND_RUNTIME AS r JOIN StringIds AS s ON r.nameId=s.id
            GROUP BY r.nameId ORDER BY total_ms DESC
        """)]
    write_csv(output / "cuda_api.csv", api_rows)
    devices = sorted({kernel["deviceId"] for kernel in kernels})
    timelines = []
    for device in devices:
        intervals = [(kernel["start"], kernel["end"]) for kernel in kernels if kernel["deviceId"] == device]
        span = max(end for _, end in intervals) - min(start for start, _ in intervals)
        active = union_duration(intervals)
        timelines.append({"device": device, "first_to_last_kernel_ms": span / 1e6,
                          "kernel_active_union_ms": active / 1e6,
                          "kernel_timeline_active_pct": 100 * active / span if span else None})
    summary = {
        "kernel_calls": len(kernels), "sum_kernel_ms": total / 1e6,
        "classes": class_rows, "timelines": timelines, "memory_copies": copies,
        "limitations": [
            "Trace timings include profiler overhead; use separate unprofiled HTTP results for performance.",
            "Kernel classes describe function names, not exact whole-request prefill/decode boundaries.",
            "Sum of kernel durations counts overlapping kernels separately; union time does not.",
            "Timeline-active percentage is not SM utilization or achieved occupancy.",
            "Copies are explicit CUDA transfers, not kernel DRAM traffic or memory bandwidth.",
            "Registers/shared memory are launch resource usage, not achieved occupancy or instruction counters.",
        ],
    }
    (output / "profile_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    lines = ["# CUDA serving trace", "", f"{len(kernels):,} kernel calls; {total / 1e6:.2f} ms summed kernel time.", "",
             "| Kernel class | Calls | GPU time (ms) | Share |", "|---|---:|---:|---:|"]
    lines.extend(f"| {row['class']} | {row['calls']} | {row['total_ms']:.2f} | {row['kernel_time_share_pct']:.1f}% |"
                 for row in class_rows)
    lines += ["", "Kernel-time shares include overlap. These are profiler observations, not serving throughput.",
              "Hardware counters (DRAM bandwidth, cache hits, achieved occupancy, instruction mix) are not present in this trace.",
              "See `kernel_summary.csv` for individual functions, launch shapes, registers and shared memory.", ""]
    (output / "profile_summary.md").write_text("\n".join(lines))
    print(f"Summarized {len(kernels):,} CUDA kernel calls in {output}")



def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tool", choices=["nsys", "ncu"], required=True)
    parser.add_argument("--profiler", required=True)
    parser.add_argument("--gate-library", type=pathlib.Path, required=True)
    parser.add_argument("--base-url", default="http://127.0.0.1:8081")
    parser.add_argument("--model", required=True, help="Model alias served by llama-server")
    parser.add_argument("--concurrency", type=int, choices=[1, 8], required=True)
    parser.add_argument("--prompt-tokens", type=int, default=2048)
    parser.add_argument("--output-tokens", type=int, default=128)
    parser.add_argument("--topics", type=pathlib.Path,
                        default=pathlib.Path(__file__).resolve().parents[1] / "prompts/topics.txt")
    parser.add_argument("--seed", type=int, default=20260912)
    parser.add_argument("--timeout", type=float, default=600)
    parser.add_argument("--output", type=pathlib.Path, required=True)
    parser.add_argument("--kernel-regex", default="mul_mat_q|mul_mat_vec_q")
    parser.add_argument("--launch-count", type=int, default=4)
    parser.add_argument("--launch-skip", type=int, default=0)
    parser.add_argument("--metrics", default=DEFAULT_METRICS)
    parser.add_argument("server_command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    server = args.server_command
    if server[:1] == ["--"]:
        server = server[1:]
    if not server or args.prompt_tokens < 1 or args.output_tokens < 1:
        parser.error("A server command and positive token counts are required")
    args.output = args.output.resolve()
    args.output.mkdir(parents=True, exist_ok=False)
    gate = args.output / "capture"
    report = args.output / "profile"
    target = ["env", f"LD_PRELOAD={args.gate_library.resolve()}",
              f"CSB_PROFILE_PREFIX={gate}", *server]
    if args.tool == "nsys":
        command = [args.profiler, "profile", "--trace=cuda,nvtx",
                   "--sample=none", "--cpuctxsw=none", "--cuda-graph-trace=node",
                   "--capture-range=cudaProfilerApi", "--capture-range-end=stop",
                   "--force-overwrite=true", f"--output={report}", *target]
    else:
        command = [args.profiler, "--profile-from-start", "off",
                   "--clock-control", "none", "--cache-control", "none",
                   "--kernel-name-base", "demangled", "--kernel-name", f"regex:{args.kernel_regex}",
                   "--launch-count", str(args.launch_count), "--launch-skip", str(args.launch_skip),
                   "--metrics", args.metrics, "--csv", "--log-file", str(args.output / "ncu.csv"),
                   "--export", str(report), *target]
    metadata = {
        "tool": args.tool, "command": command, "server_command": server,
        "concurrency": args.concurrency, "target_prompt_tokens": args.prompt_tokens,
        "output_tokens": args.output_tokens, "profiled_requests": args.concurrency,
        "topics_file": str(args.topics.resolve()), "seed": args.seed,
        "warmup_requests": args.concurrency, "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "timing_use": "diagnostic only; do not mix with unprofiled serving performance",
        "environment": {key: os.environ.get(key) for key in
                        ["CUDA_VISIBLE_DEVICES", "LD_LIBRARY_PATH", "GGML_CUDA_DISABLE_GRAPHS"]},
    }
    # Nsight embeds its inherited environment in reports. The local-model server
    # needs no download credentials or editor/session environment.
    profiler_environment = {key: value for key, value in os.environ.items() if key in {
        "PATH", "HOME", "USER", "LOGNAME", "SHELL", "TMPDIR", "TMP", "TEMP",
        "LANG", "LC_ALL", "LC_CTYPE", "LD_LIBRARY_PATH", "CUDA_VISIBLE_DEVICES",
        "CUDA_DEVICE_ORDER", "CUDA_MODULE_LOADING", "CUDA_CACHE_PATH",
        "CUDA_HOME", "CUDA_PATH", "CUBLAS_WORKSPACE_CONFIG", "NVIDIA_TF32_OVERRIDE",
        "OMP_NUM_THREADS", "GGML_CUDA_DISABLE_GRAPHS", "GGML_CUDA_FORCE_MMQ",
        "GGML_CUDA_FORCE_CUBLAS",
    }}
    metadata["profiler_environment_keys"] = sorted(profiler_environment)
    (args.output / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
    log = (args.output / "server-profiler.log").open("w")
    process = None
    exit_code = 0

    def require_running() -> None:
        if process.poll() is not None:
            raise RuntimeError(f"Profiler/server exited with {process.returncode}; see server-profiler.log and ncu.csv")
        error = pathlib.Path(str(gate) + ".error")
        if error.exists():
            raise RuntimeError("CUDA profiler gate: " + error.read_text())

    def wait_gate(suffix: str) -> None:
        deadline = time.monotonic() + min(args.timeout, 60)
        while not pathlib.Path(str(gate) + suffix).exists():
            require_running()
            if time.monotonic() > deadline:
                raise TimeoutError(f"Profiler gate did not acknowledge {suffix}")
            time.sleep(0.02)

    def burst(prepared: list) -> list:
        barrier = threading.Barrier(args.concurrency)

        def request(index):
            messages, prompt_tokens = prepared[index]
            barrier.wait()
            record = stream_completion(args.base_url, args.model, messages,
                                       args.output_tokens, args.timeout, args.seed + index)
            finalize_record(record, prompt_tokens, args.output_tokens)
            record.pop("_text", None)
            return {"index": index, "prepared_prompt_tokens": prompt_tokens, **record}

        with concurrent.futures.ThreadPoolExecutor(max_workers=args.concurrency) as pool:
            return list(pool.map(request, range(args.concurrency)))

    try:
        try:
            with urllib.request.urlopen(args.base_url + "/health", timeout=2):
                raise RuntimeError("A server already occupies the requested URL")
        except urllib.error.URLError:
            pass
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=True, env=profiler_environment)
        deadline = time.monotonic() + args.timeout
        while True:
            require_running()
            try:
                with urllib.request.urlopen(args.base_url + "/health", timeout=2) as response:
                    if response.status == 200:
                        break
            except urllib.error.URLError:
                pass
            if time.monotonic() > deadline:
                raise TimeoutError("Server did not become healthy")
            time.sleep(0.2)
        tokenizer = ServerTokenizer(args.base_url, args.timeout)
        topics = [line.strip() for line in args.topics.read_text().splitlines() if line.strip()]
        if not topics:
            raise ValueError("The topics file is empty")
        prepared = [make_messages(tokenizer, topics[i % len(topics)], i, args.prompt_tokens)
                    for i in range(args.concurrency)]
        (args.output / "prompts.json").write_text(json.dumps(prepared, indent=2) + "\n")
        metadata["warmup"] = burst(prepared)
        if any(not record["ok"] for record in metadata["warmup"]):
            raise RuntimeError("Warmup failed")
        pathlib.Path(str(gate) + ".start").touch()
        wait_gate(".started")
        metadata["requests"] = burst(prepared)
        pathlib.Path(str(gate) + ".stop").touch()
        wait_gate(".stopped")
        if any(not record["ok"] for record in metadata["requests"]):
            raise RuntimeError("One or more profiled requests failed")
        metadata["status"] = "captured"
    except Exception as error:
        metadata["status"] = "failed"
        metadata["error"] = f"{type(error).__name__}: {error}"
        print(metadata["error"], flush=True)
        exit_code = 2
    finally:
        if process is not None:
            # Signal only the server first so the profiler can finalize/export.
            pid_file = pathlib.Path(str(gate) + ".pid")
            if pid_file.exists():
                try:
                    os.kill(int(pid_file.read_text()), signal.SIGINT)
                except ProcessLookupError:
                    pass
            try:
                process.wait(timeout=60)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
            metadata["profiler_exit_code"] = process.returncode
            if process.returncode != 0 and not exit_code:
                metadata["status"] = "failed"
                metadata["error"] = f"Profiler exited with {process.returncode}"
                exit_code = 2
        log.close()
        if args.tool == "ncu":
            counter_log = args.output / "ncu.csv"
            counter_text = counter_log.read_text(errors="replace") if counter_log.exists() else ""
            if "ERR_NVGPUCTRPERM" in counter_text:
                metadata["counter_status"] = "permission_denied"
                metadata["status"] = "failed"
                metadata["error"] = "ERR_NVGPUCTRPERM: NVIDIA hardware-counter permission denied"
                exit_code = 2
            elif not report.with_suffix(".ncu-rep").exists():
                metadata["counter_status"] = "no_report"
                metadata["status"] = "failed"
                metadata.setdefault("error", "Nsight Compute produced no counter report")
                exit_code = 2
            else:
                metadata["counter_status"] = "report_created"
        (args.output / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
    if args.tool == "nsys" and report.with_suffix(".nsys-rep").exists():
        with (args.output / "export.log").open("w") as export_log:
            exported = subprocess.run([args.profiler, "export", "--type=sqlite", "--force-overwrite=true",
                                       f"--output={report}.sqlite", f"{report}.nsys-rep"],
                                      stdout=export_log, stderr=subprocess.STDOUT, env=profiler_environment)
        if exported.returncode:
            return 2
        summarize_sqlite(report.with_suffix(".sqlite"), args.output)
    print(f"Profile {metadata['status']}: {args.output}", flush=True)
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
