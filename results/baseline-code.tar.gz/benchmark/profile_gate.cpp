// A process-local CUDA profiler gate. The HTTP driver creates .start/.stop;
// acknowledgements ensure warmup and model loading remain outside the capture.
#include <cuda_profiler_api.h>
#include <cuda_runtime_api.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <pthread.h>
#include <string>
#include <unistd.h>

static void write_file(const std::string &path, const char *value) {
    if (FILE *file = fopen(path.c_str(), "w")) {
        fputs(value, file);
        fclose(file);
    }
}

static void *watch_gate(void *argument) {
    const std::string prefix(static_cast<char *>(argument));
    free(argument);
    while (access((prefix + ".start").c_str(), F_OK) != 0) usleep(10000);
    cudaError_t status = cudaSetDevice(0);  // CUDA_VISIBLE_DEVICES selects the GPU.
    if (status == cudaSuccess) status = cudaProfilerStart();
    if (status != cudaSuccess) {
        write_file(prefix + ".error", cudaGetErrorString(status));
        return nullptr;
    }
    write_file(prefix + ".started", "ok\n");
    while (access((prefix + ".stop").c_str(), F_OK) != 0) usleep(10000);
    status = cudaDeviceSynchronize();
    if (status == cudaSuccess) status = cudaProfilerStop();
    write_file(prefix + (status == cudaSuccess ? ".stopped" : ".error"),
               status == cudaSuccess ? "ok\n" : cudaGetErrorString(status));
    return nullptr;
}

__attribute__((constructor)) static void initialize_gate() {
    const char *prefix = getenv("CSB_PROFILE_PREFIX");
    if (!prefix || !*prefix) return;
    char pid[32];
    snprintf(pid, sizeof(pid), "%ld\n", static_cast<long>(getpid()));
    write_file(std::string(prefix) + ".pid", pid);
    pthread_t thread;
    char *copy = strdup(prefix);
    if (pthread_create(&thread, nullptr, watch_gate, copy) == 0) {
        pthread_detach(thread);
    } else {
        free(copy);
        write_file(std::string(prefix) + ".error", "pthread_create failed\n");
    }
}
